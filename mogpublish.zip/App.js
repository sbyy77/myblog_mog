import "./App.css";
import ContextProvider from "./components/common/context/context";
// import MogPost from "./pages/mogPost";
// import MogUserInfo from "./pages/mogUserInfo";
// import MogLogin from "./pages/mogLogin";
// import MogMain from "./pages/mogMain";
import MogPublish from "./pages/mogPublish";

function App() {
    return (
        <>
            {/* <ContextProvider>
                <MogMain />
            </ContextProvider> */}
            <ContextProvider>
                <MogPublish />
            </ContextProvider>
            {/* <MogLogin /> */}
            {/* <ContextProvider>
                <MogPost />
            </ContextProvider> */}
            {/* <ContextProvider>
                <MogUserInfo/>
            </ContextProvider> */}
        </>
    );
}

export default App;
