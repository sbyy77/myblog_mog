export const Post = [
    {
        cid: 1,
        category: "전체보기",
        board: [
            // {
            //     cid: 1,
            //     bid: 1,
            //     title: "useState",
            // },
            // { cid: 1, bid: 2, title: "useEffect" },
            // { cid: 1, bid: 3, title: "redux" },
        ],
    },
    {
        cid: 2,
        category: "ReactJs",
        board: [
            {
                cid: 2,
                bid: 1,
                title: "useState",
            },
            { cid: 2, bid: 2, title: "useEffect" },
            { cid: 2, bid: 3, title: "redux" },
        ],
    },
    {
        cid: 3,
        category: "Java",
        board: [
            {
                cid: 3,
                bid: 4,
                title: "spring",
            },
            { cid: 3, bid: 5, title: "jsp" },
        ],
    },
    {
        cid: 4,
        category: "NodeJS",
        board: [
            {
                cid: 4,
                bid: 6,
                title: "request",
            },
            { cid: 4, bid: 7, title: "response" },
        ],
    },
    {
        cid: 5,
        category: "Math",
        board: [
            {
                cid: 5,
                bid: 8,
                title: "Algebra",
            },
            { cid: 5, bid: 9, title: "Geometry" },
            { cid: 5, bid: 10, title: "Topology" },
            { cid: 5, bid: 11, title: "Number Theory" },
            { cid: 5, bid: 12, title: "Complex Algebrea" },
        ],
    },
    {
        cid: 6,
        category: "Language",
        board: [
            {
                cid: 6,
                bid: 13,
                title: "English",
            },
            { cid: 6, bid: 14, title: "French" },
            { cid: 6, bid: 15, title: "German" },
            { cid: 6, bid: 16, title: "Spanish" },
            { cid: 6, bid: 17, title: "Russian" },
        ],
    },
];
