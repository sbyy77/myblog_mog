import PostList from "./postList";
import PostReply from "./postReply";
import DownArrow from "../../../images/postImages/arrow_down_icon.png";
import UpAarrow from "../../../images/postImages/arrow_up_icon.png";
import Share from "../../../images/postImages/share.png";
import styled from "styled-components";

const PostFooter = () => {
    return (
        <>
            <PostFooterMenu>
                <PostReplyWrap>
                    <span>댓글</span>
                    <ArrowImg />
                </PostReplyWrap>
                <PostLove>
                    <ShareImg />
                    <span>공감 ♡</span>
                </PostLove>
            </PostFooterMenu>
            <PostReply />
            <PostList />
        </>
    );
};
export default PostFooter;

const PostFooterMenu = styled.div`
    font-size: 1.1rem;
    display: flex;
    padding: 1rem;
    /* border-bottom: 0.125rem solid rgb(102, 100, 255);
    // box-shadow: rgb(0 0 0 / 8%) 0px 0px 8px; 
    box-shadow: 0rem 1.25rem 1.25rem -1.125rem rgb(102, 100, 255, 0.2); */
    justify-content: space-between;
`;

const ArrowImg = styled.i`
    width: 1.5rem;
    height: 1.2rem;
    background: url(${DownArrow}) no-repeat center;
    background-size: contain;
    display: inline-block;
    /* position: absolute; */
`;
const PostReplyWrap = styled.div`
    display: flex;
    align-items: center;
    cursor: pointer;
`;
const ShareImg = styled.i`
    width: 1.5rem;
    height: 0.95rem;
    background: url(${Share}) no-repeat center;
    background-size: contain;
    display: inline-block;
    margin-right: 1rem;
`;

const PostLove = PostReplyWrap;
