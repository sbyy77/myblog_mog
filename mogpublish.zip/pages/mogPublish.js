
import PublishContainer from "../components/common/container/publishContainer";
import PublishHeader from "../components/publishContent/publishHeader/publishHeader";

const MogPublish = () => {
    return (
        <>
            <PublishHeader />
            <PublishContainer/>
        </>
    );
};

export default MogPublish;
